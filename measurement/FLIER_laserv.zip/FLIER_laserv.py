#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Jan  9 12:11:05 2023

@author: schneehagen
"""

#import acoular
from pylab import *
from acoular import *
from os import path, remove, system
mpl.style.use('classic')

td_dir='/home/schneehagen/Nextcloud/Dokumente/Messungen/2023_FLIER/spectacoular-master/apps/Measurement_App/td'
file_name = '2023-05-25_11-01-17_980771'

m2=0.426 #masse table shaker
calib=0.025 #wegen 100 (mm/s)/V von Laservibrometer - siehe Bedienungsanleitung, EINSTELLUNGEN auf Display: Velo 100, Lp22, Hp none

g=9.81
f_soll=array([5, 14, 24, 74, 141, 200, 2000])
g_soll=array([0.1, 1.0, 1.1, 10.1, 10.2, 20.4, 20.4]) # Amplituden und Frequenezen aus RCA (M. Pohl BTU)

#FFT
temp=25
invalid=[1,2,3] # laservibrometer an channel 0
#fourier_window='Hanning'
fourier_window='Rectangular'
fourier_overlap='50%'
fourier_blocksize=8192*4
fs=51200
factor=fs/fourier_blocksize

#Berechnung
td=MaskedTimeSamples()
td.name=path.join(td_dir, file_name+'.h5')
td.invalid_channels = invalid 

f=PowerSpectra(window=fourier_window,overlap=fourier_overlap,block_size=fourier_blocksize,ind_low=1,ind_high=-1)
f.time_data=td
freq=f.fftfreq()

v=sqrt(real(f.csm[:,0,0]))*calib #aus der csm kommt der effektivwert zum quadrat
a=v*(2*pi*freq) # umrechnung schnelle --> beschleunigung

figure(1)
semilogx(freq[1:], 10*log10(a[1:]/g))
xlabel('frequency in Hz')
ylabel('10*log10(a/g)')
grid('on')
xlim(1, 2500)

scatter(f_soll, 10*log10(g_soll))
